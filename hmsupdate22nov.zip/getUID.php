<?php 
        require_once("connect.php");
        $sql ="SELECT rfid_uid,id FROM tb_registrasi order by id desc limit 1";
        $query= $dbh -> prepare($sql);
        $query-> execute();
        $results = $query -> fetchAll(PDO::FETCH_OBJ);
        if($query -> rowCount() > 0)
        {
            foreach ($results as $result) 
            {
                echo htmlentities($result->rfid_uid);
            }
        }

?>
