<?php
 $title="Beranda";
?>

<?=content_open_default('Halaman Beranda')?>
          Start creating your amazing application!
<?=content_close()?>