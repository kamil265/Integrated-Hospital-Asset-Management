<?php
 $title="Data Log Tenaga Medis";
?>