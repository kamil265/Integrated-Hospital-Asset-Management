<?php
$_dir=__DIR__;
define('env', $_dir);
include(env.'/env.php');

// helpers
include '_helpers/helper.php';
