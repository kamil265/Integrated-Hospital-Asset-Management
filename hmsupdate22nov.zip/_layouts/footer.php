
<div class="footer">
  <div class="copyright">
    <p>Copyright © 2020. Integrated Hospital Asset Management</p>
  </div>
</div>