<?php
    class Mobil{
        public $warna = "biru";
        public $merk = "porsche";
        public $maxspeed = "80";

        public function speedUp(){
            return "$warna";
        }
    }
?>