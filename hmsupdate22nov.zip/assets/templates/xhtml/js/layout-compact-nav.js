(function($) {
    "use strict"
    
    new dezSettings({
        sidebarStyle: "compact"
    });


})(jQuery);