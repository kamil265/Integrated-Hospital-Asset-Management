<?php
    session_start();
    error_reporting(0);
    include 'connect.php';
    if(strlen($_SESSION['alogin'])==0)
    {   
        header('location:index.php');
    }
    else{ 
        if(isset($_POST['insertclinicalpasien']))
        {
            $tag_id = $_POST['tag_id'];
            $tanggal_masuk = $_POST['tanggal_masuk'];
            $nama_pasien = $_POST['nama_pasien'];
            $jenis_pasien = $_POST['jenis_pasien'];
            $dokter = $_POST['dokter'];
            $diagnosa = $_POST['diagnosa'];
            
            $asal_ruang = $_POST['asal_ruang'];
            $ruang_pemindahan = $_POST['ruang_pemindahan'];
            
            $sql="INSERT INTO  tb_clinical_pasien(tag_id,tanggal_masuk,nama_pasien,jenis_pasien,dokter,diagnosa,asal_ruang,ruang_pemindahan) VALUES (:tag_id,:tanggal_masuk,:nama_pasien,:jenis_pasien,:dokter,:diagnosa,:asal_ruang,:ruang_pemindahan)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':tag_id',$tag_id,PDO::PARAM_STR);
            $query->bindParam(':tanggal_masuk',$tanggal_masuk,PDO::PARAM_STR);
            $query->bindParam(':nama_pasien',$nama_pasien,PDO::PARAM_STR);
            $query->bindParam(':jenis_pasien',$jenis_pasien,PDO::PARAM_STR);
            $query->bindParam(':dokter',$dokter,PDO::PARAM_STR);
            $query->bindParam(':diagnosa',$diagnosa,PDO::PARAM_STR);
            
            $query->bindParam(':asal_ruang',$asal_ruang,PDO::PARAM_STR);
            $query->bindParam(':ruang_pemindahan',$ruang_pemindahan,PDO::PARAM_STR);
            
            $query->execute();
            $lastInsertId = $dbh->lastInsertId();
            if($lastInsertId)
            {
                $_SESSION['msg']="Book Listed successfully";
                header('location:index.php?halaman=clinicalmng-pasien');
            }
            else 
            {
                $_SESSION['error']="Something went wrong. Please try again";
                header('location:index.php');
            }
        }
    }
?>