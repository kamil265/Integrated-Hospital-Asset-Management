	<!-- Dashboard 1 -->
	<script src="<?=templates()?>js/dashboard/dashboard-1.js"></script>

	<!-- Required vendors -->
    <script src="<?=templates()?>vendor/global/global.min.js"></script>
	<script src="<?=templates()?>vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="<?=templates()?>vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="<?=templates()?>js/custom.min.js"></script>
	<script src="<?=templates()?>js/deznav-init.js"></script>
	<!-- Apex Chart -->
	<script src="<?=templates()?>vendor/apexchart/apexchart.js"></script>
	
	<!-- Chartist -->
    <script src="<?=templates()?>vendor/chartist/js/chartist.min.js"></script>
    <script src="<?=templates()?>vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js"></script>
    
	<!-- Flot -->
    <script src="<?=templates()?>vendor/flot/jquery.flot.js"></script>
    <script src="<?=templates()?>vendor/flot/jquery.flot.pie.js"></script>
    <script src="<?=templates()?>vendor/flot/jquery.flot.resize.js"></script>
    <script src="<?=templates()?>vendor/flot-spline/jquery.flot.spline.min.js"></script>
	
	<!-- Chart sparkline plugin files -->
    <script src="<?=templates()?>vendor/jquery-sparkline/jquery.sparkline.min.js"></script>
	<script src="<?=templates()?>js/plugins-init/sparkline-init.js"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?=templates()?>vendor/peity/jquery.peity.min.js"></script>
	<script src="<?=templates()?>js/plugins-init/piety-init.js"></script>
	
    <!-- Init file -->
    <script src="<?=templates()?>js/plugins-init/widgets-script-init.js"></script>
    <script src="<?=templates()?>vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?=templates()?>js/plugins-init/datatables.init.js"></script>

    <!-- Daterangepicker -->
    <!-- momment js is must -->
    <script src="<?=templates()?>vendor/moment/moment.min.js"></script>
    <script src="<?=templates()?>vendor/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- clockpicker -->
    <script src="<?=templates()?>vendor/clockpicker/js/bootstrap-clockpicker.min.js"></script>
    <!-- asColorPicker -->
    <script src="<?=templates()?>vendor/jquery-asColor/jquery-asColor.min.js"></script>
    <script src="<?=templates()?>vendor/jquery-asGradient/jquery-asGradient.min.js"></script>
    <script src="<?=templates()?>vendor/jquery-asColorPicker/js/jquery-asColorPicker.min.js"></script>
    <!-- Material color picker -->
    <script src="<?=templates()?>vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
    <!-- pickdate -->
    <script src="<?=templates()?>vendor/pickadate/picker.js"></script>
    <script src="<?=templates()?>vendor/pickadate/picker.time.js"></script>
    <script src="<?=templates()?>vendor/pickadate/picker.date.js"></script>



    <!-- Daterangepicker -->
    <script src="<?=templates()?>js/plugins-init/bs-daterange-picker-init.js"></script>
    <!-- Clockpicker init -->
    <script src="<?=templates()?>js/plugins-init/clock-picker-init.js"></script>
    <!-- asColorPicker init -->
    <script src="<?=templates()?>js/plugins-init/jquery-asColorPicker.init.js"></script>
    <!-- Material color picker init -->
    <script src="<?=templates()?>js/plugins-init/material-date-picker-init.js"></script>
    <!-- Pickdate -->
    <script src="<?=templates()?>js/plugins-init/pickadate-init.js"></script>
	<script src="<?=templates()?>js/pindah-aset.js"></script>

    <script src="<?=templates()?>js/plugins-init/clock-picker-init.js"></script>
    <script src="<?=templates()?>js/showEditCategory.js"></script>
    <script src="<?=templates()?>js/showEditAsset.js"></script>
    <script src="<?=templates()?>js/showEditPeminjaman.js"></script>
    <script src="<?=templates()?>js/showEditJadwal.js"></script>
    <script src="<?=templates()?>js/showEditPasien.js"></script>
    <script src="<?=templates()?>js/showEditDokter.js"></script>
    <script src="<?=templates()?>js/showEditPerawat.js"></script>
    <script src="<?=templates()?>js/showEditKaryawan.js"></script>


    <script src="<?=templates()?>js/getUID.js"></script>

    <script src="<?=templates()?>vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="<?=templates()?>js/plugins-init/chartjs-init.js"></script>






