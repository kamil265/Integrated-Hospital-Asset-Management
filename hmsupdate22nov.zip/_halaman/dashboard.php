<?php
 $title="Dashboard";
 require_once 'connect.php';
?>
<div class="container-fluid">
    <div class="form-head d-flex mb-2 align-items-start">
		<div class="mr-auto d-none d-lg-block">
			<h3 class="text-primary font-w600">Welcome to Integrated Hospital Asset Management</h3>
			<p class="mb-0">Quick Access</p>
		</div>
    </div>	
	<div class="row">
	    <div class="col-xl-4 col-lg-4 col-sm-4">
            <a href="<?=url('clinicalmng-pasien#log-data-pasien')?>">
            <div class="widget-stat card">
                <div class="card-body p-4">
                    <div class="media ai-icon">
                        <span class="mr-3 bgl-warning text-info">
							<i class="fas fa-procedures"></i>
                        </span>
                        <div class="media-body">
                            <p class="mb-1">Log Data</p>
                            <h5 class="mb-0">Pasien</h5>
                            <!-- <span class="badge badge-warning">+250</span> -->
                        </div>
                    </div>
                </div>
            </div>
            </a>
            
        </div>
        <div class="col-xl-4 col-lg-4 col-sm-4">
            <a href="<?=url('clinicalmng-nakes#log-data-nakes')?>">
            <div class="widget-stat card">
                <div class="card-body p-4">
                    <div class="media ai-icon">
                        <span class="mr-3 bgl-warning text-info">
							<i class="fas fa-user-md"></i>
			            </span>
                        <div class="media-body">
                            <p class="mb-1">Log Data</p>
                            <h5 class="mb-0">Tenaga Kesehatan</h5>
                            <!-- <span class="badge badge-warning">+250</span> -->
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
		<div class="col-xl-4 col-lg-4 col-sm-4">
            <a href="">
            <div class="widget-stat card">
                <div class="card-body p-4">
                    <div class="media ai-icon">
                        <span class="mr-3 bgl-warning text-info">
							<i class="fas fa-medkit"></i>
                        </span>
                        <div class="media-body">
                            <p class="mb-1">Riwayat</p>
                            <h5 class="mb-0">Peminjaman Aset</h5>
                            <!-- <span class="badge badge-warning">+250</span> -->
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <div class="col-xl-12 col-xxl-12 col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header border-0 pb-0">
					<h4 class="card-title">Patients (%)</h4>
				</div>
				<div class="card-body pt-2">
					<h4 class="text-dark font-w400">Total Patient</h4>
					<h3 class="text-primary font-w600">562,084 People</h3>
					<div class="row mx-0 align-items-center">
						<div class="col-sm-8 col-md-7  px-0">
                            <canvas id="doughnut_chart" width="400" height="400"></canvas>
						</div>
						<div class="col-sm-4 col-md-5 px-0">
							<div class="patients-chart-deta">
								<div class="col px-0">
									<span class="bg-danger"></span>	
							        <div>
									    <p>New</p>
									    <h3>64%</h3>
								    </div>
								</div>
								<div class="col px-0">
									<span class="bg-success"></span>	
									<div>
										<p>Recovered</p>
										<h3>73%</h3>
									</div>
								</div>
								<div class="col px-0">
									<span class="bg-warning"></span>	
								    <div>
										<p>In Treatment</p>
										<h3>48%</h3>
									</div>
								</div>
							</div>
						</div>
					</div>				
				</div>
			</div>
		</div>
    </div>
</div>
<script>
$.getJSON( "http://localhost:/RS/getGrafikData.php", function( data ) {
    var TabelData="";
    $(data).each(function(i){ 
        TabelData +="<tr><td>"+data[i].NamaProduk+"</td><td>"+data[i].JmlItem+"</td></tr>"; 
    });
    //tampilkan di tabel id DataTabelProduk
    $("#DatatTabelProduk").html(TabelData);

    //array untuk chart label dan chart data
    var isi_labels = [];
    var isi_data=[];
    var TotalJml = 0;
    //menghitung total jumlah item
    data.forEach(function (obj) {
        TotalJml += Number(obj["JmlItem"]);
    });

    //push ke dalam array isi label dan isi data
    var JmlItem = 0;
    $(data).each(function(i){         
        isi_labels.push(data[i].NamaProduk); 
        //jml item dalam persentase
        isi_data.push(((data[i].JmlItem/TotalJml) * 100).toFixed(2));
    });

    //deklarasi chartjs untuk membuat grafik 2d di id mychart   
    var ctx = document.getElementById('myChart').getContext('2d');

    var myPieChart = new Chart(ctx, {
        //chart akan ditampilkan sebagai pie chart
        type: 'pie',
        data: {
            //membuat label chart
            labels: isi_labels,
            datasets: [{
                label: 'Data Produk',
                //isi chart
                data: isi_data,
                //membuat warna pada chart
                backgroundColor: [
                    'rgb(26, 214, 13)',
                    'rgb(235, 52, 110)',
                    'rgb(52, 82, 235)',
                    'rgb(138, 4, 113)',
                    'rgb(214, 134, 13)'
                ],
                //borderWidth: 0, //this will hide border
            }]
        },
        options: {
            //konfigurasi tooltip
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        var dataset = data.datasets[tooltipItem.datasetIndex];
                        var labels = data.labels[tooltipItem.index];
                        var currentValue = dataset.data[tooltipItem.index];
                        return labels+": "+currentValue+" %";
                    }
                }
            }
          }
    });
});
</script>
